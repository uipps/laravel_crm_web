import React from 'react';
import { Form, Button } from 'antd';
import assets from './assets/index';
import './style.less';

const items = [
  {
    label: '名称',
    id: 'k1',
    type: 'input',
    formatData(val) {},
  },
  {
    label: '国家',
    id: 'k2',
    options: [
      {
        key: 'all',
        value: '全部',
      },
      {
        key: 'k1',
        value: '第一个',
      },
    ],
    type: 'select',
  },
  {
    label: '名称',
    id: 'k3',
    type: 'input',
  },
  {
    label: '国家',
    id: 'k4',
    options: [
      {
        key: 'all',
        value: '全部',
      },
    ],
    type: 'select',
  },
  {
    label: '名称',
    id: 'k5',
    type: 'input',
  },
  {
    label: '国家',
    id: 'k6',
    type: 'select',
  },
];

const values = {};

const onChange = ({ key, value }) => {
  values[key] = value;
};

const onFinish = () => {
  console.log(values);
};

const renderItem = (item, props) => {
  const { label, id, type } = item;
  const { Component } = assets[type];
  const value = props.values[id];
  debugger;
  console.log(id, value);

  return (
    <div className="filter__item" key={id}>
      <Form.Item label={label} labelAlign="right" name={id}>
        {React.cloneElement(
          <Component />,
          { onChange, val: value, ...item },
          null,
        )}
      </Form.Item>
    </div>
  );
};

export default function(props) {
  const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };

  return (
    <Form className="filter-comp" name="filter" {...layout} onFinish={onFinish}>
      {Array.isArray(items) && items.map(item => renderItem(item, props))}

      <div className="filter__item">
        <Form.Item>
          <Button type="primary" htmlType="submit">
            {'查询'}
          </Button>
        </Form.Item>
      </div>
    </Form>
  );
}
