import { Select } from 'antd';
export default function(props) {
  const { options = [], id, onChange, value } = props;

  const handleChange = value => {
    onChange({ key: id, value });
  };

  return (
    <Select value={value} onChange={handleChange}>
      {Array.isArray(options) &&
        options.map(item => (
          <Select.Option key={item.key} value={item.key}>
            {item.value}
          </Select.Option>
        ))}
    </Select>
  );
}
