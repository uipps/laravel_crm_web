import Input from './Input';
import Select from './Select';

export default {
  input: {
    Component: Input,
    formatData: [],
  },
  select: {
    Component: Select,
    formatData: [],
  },
};
