import { Input } from 'antd';

export default function(props) {
  const { onChange, id, val } = props;

  const handlerChange = e => {
    const { value } = e.currentTarget;
    onChange({ key: id, value });
  };
  console.log(props, val);
  return <Input value={val} onChange={handlerChange} />;
}
